## CHANGELOG
* v2.5 - Add blocktestimonial Exploit
* v2.5 - Add Cubed Theme Exploit
* v2.5 - Add Rightnow Theme Exploit
* v2.5 - Add Konzept Exploit
* v2.5 - Add Omni Secure Files Exploit
* v2.5 - Add Pitchprint Exploit
* v2.5 - Add Satoshi Exploit
* v2.5 - Add Pinboard Exploit
* v2.5 - Add Barclaycart Exploit
* v2.5 - Add Com Facileforms Exploit
* v2.5 - Add Com Jwallpapers Exploit
* v2.5 - Add Com Extplorer Exploit
* v2.5 - Add Com Rokdownloads Exploit
* v2.5 - Add Com Sexycontactform Exploit
* v2.5 - Add Com Jbcatalog Exploit
* v2.5 - Update Com Blog Exploit
* v2.5 - Update Com Foxcontact Exploit
* v2.5 - Add Drupal Geddon Exploit
